<?php
require  'C:\xampp\htdocs\30_test\index.php';
	class result {
		function Tdata() {
				$sum = filter_var(trim($_POST['sum']), FILTER_SANITIZE_STRING); //filter_var - позволяет отфильтровать значение, удалить различные html символы, а так же символы, которые лучше не добавлять в БД. trim($_POST['login'] - строка фильтрации, FILTER_SANITIZE_STRING тип фильтрации | trim - удаляет лишние пробелы из какой-либо строки
				$tax = filter_var(trim($_POST['tax']), FILTER_SANITIZE_STRING); //filter_var - позволяет отфильтровать значение, удалить различные html символы, а так же символы, которые лучше не добавлять в БД. trim($_POST['login'] - строка фильтрации, FILTER_SANITIZE_STRING тип фильтрации | trim - удаляет лишние пробелы из какой-либо строки
			
			if ('POST' == $_SERVER['REQUEST_METHOD']) {
				if (isset($tax, $sum)) {
					if (mb_strlen($sum, 'utf-8') > 1 && mb_strlen($sum, 'utf-8') < 8
						&& mb_strlen($tax, 'utf-8') > 0 && mb_strlen($tax, 'utf-8') < 3) {
						echo "СУММА :".$sum."<br \>";
						echo "СТАВКА :".$tax;
						$str = $sum * $tax / 100;
						echo '<br />Ответ: '.$str;
						exit;
					} else {
						echo "Недопустимая длина (диапазон значений: <b> СУММА: </b>от 2 до 7, <b> СТАВКА: </b>от 1 до 2)";
						exit;
				}
			}}




// var_dump($sum);
			
}
}

	$form = new result;
	$form -> Tdata();


header('Location: http://localhost/30_test/');
