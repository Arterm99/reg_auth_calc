<?php
require_once ('../head.php');
require_once ('check.php');
// require  'C:\xampp\htdocs\30_test\index.php';



	$test = new check;
	$test->header();
	$test->Tdata();
	$test->cookie();

// header('Location: http://localhost/30_test/');



