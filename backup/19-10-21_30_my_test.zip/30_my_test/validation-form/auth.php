<?php 

require_once('check.php');

class auth extends check {

	function db_auth() {
// Подкючение к БД
			echo "Привет, мир";
			echo $this->login1;
}}

$auth = new auth();
$auth->db_auth();