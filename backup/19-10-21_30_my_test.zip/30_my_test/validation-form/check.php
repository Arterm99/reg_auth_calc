<?php

class check {

	public $login;
	public $pass;
	private $name;
	private $db;
	private $fetch;
	private $rows;
	private $mysql;


public $login1 = "Супер";
	function db_reg() {
// Подкючение к БД
	
		// Назначение переменных
	$login = filter_var(trim($_POST['login']), FILTER_SANITIZE_STRING);
	$name = filter_var(trim($_POST['name']), FILTER_SANITIZE_STRING);
	$pass = filter_var(trim($_POST['pass']), FILTER_SANITIZE_STRING);
	
	if (empty($login)) exit("Поле \"Логин\"не заполнено");
	if (empty($name)) exit("Поле \"Имя\" не заполнено");
	if (empty($pass)) exit("Введите пароль"); // empty - возвращает True, если строка пустая, и False, если строка содержит хотя бы один символ

	// Хеширование пароля
	$pass = md5($pass."adadwadsagea123"); // adadwadsagea123 - любые символы, md5- хеширует пароль

	try { 
	$db = new PDO ('mysql:host=localhost; dbname=script-01', 'root', '' ); // *msqli - имя источника данных (DSN).

	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);		   // Установить исключения при ошибках в базе данных


	// 1 Вариант. Проверка на дублирование логинов
	$fetch = $db->query('SELECT login FROM users');
	$rows = $fetch->fetchAll();
		foreach($rows as $row) {
			if ($login === $row[0]) {
		echo "Такой логин существует<br \>";
		echo "Приветствуем Вас, <b>$login</b>";
		// header('Location: /30_my_test/');
		return;
	}} 

	// 2 Вариант. Проверка на дублирование логинов
	// $result = $db->query("SELECT * FROM `users` WHERE `login` = '$login' AND `pass` = '$pass'"); // '*' - выбираем ВСЁ, ОБЯЗАТЕЛЬНО СМОТРИ КАВЫЧКИ!!!!!!!!!

	// // ! Получаем записи в формате объекта, что не оч удобно !
	// // Лучше с массивом
	// $user = $result->fetch_assoc(); // fetch_assoc - конвертирует в массив
	// // Подсчитываем колличество элементов внутри массива
	// if(count($user) == 0) {// если длина массива = 0 | count - подсчитывает колличество элементов внутри массива
	// 	echo "Такой пользователь не найден";
	// 	exit(); // выход
	// }


	// Заносим информацию в БД
	if ($login) {
	$mysql = $db->prepare("INSERT INTO users (login, name, pass) 
							VALUES (?,?,?)")->execute(array($login, $name, $pass)); // с помощью execute вставляются значения вместо ?,?,? в методе prepare; // Метод prepare() безопастно возвращает количество строк таблицы, затребованных в запросе SQL, отправленном серверу базы данных
	echo "Приветствуем Вас, <b>$login</b><br \>";
	//Выявление количества строк таблицы, затронутых при выполнении запроса SQL с командой UPDATE
	echo 'В таблицу занесена '.$mysql.' строка';
	// header('Location: /30_my_test/');
	}
			/* РАБОТА С БАЗОЙ ДАННЫХ ===================================================-
			 Обновляем значение (name) в таблице
			$mysql = $db->exec("UPDATE users SET name = 'Ar' WHERE id > 1"); // Метод exec

			if(1>2) { $mysql = $db->exec("DELETE FROM users WHERE login = 'asdq'");  }
 
			 ИНАЧЕ УДАЛЯЕМ ВСЕ СТРОКИ ИЗ ТАБЛИЦЫ
			 else {
			 	$mysql = $db->exec("DELETE FROM users");
			 }
			 Удаление таблицы из базы данных
			 DROP TABLE dishes
			 header('Location: /');
			 =========================================================================- */

	// Куки
	setcookie('user', $login, time() + 3600, "/");




	} // Закрывает try
	catch (PDOException $е) {
	print "Ошибка: " . $e->getMessage();
	}

}}


$test = new check;
// $test->db_reg();


// Выводит букву

// $fetch = $db->query('SELECT login FROM users');
// while ($row = $fetch->fetch()) {
// 	$qwe = implode(', ', $row) . "<br \>";
// 	echo $qwe[0];
// 	return;
// }

// Выводит слова

// $fetch = $db->query('SELECT id, login FROM users');
// while ($row = $fetch->fetch()) {
// 	$qwe = "$row[id], $row[login] . <br \>";
// 	echo $qwe;
// }