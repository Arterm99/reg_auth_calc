<?php 

setcookie ('user', $login, time() - 3600, "/");
header('Location: /30_my_test/');