<?php

require_once('check.php');

$test->db_reg();